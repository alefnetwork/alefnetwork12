<?php

header('Content-type:image/png');
$rand=rand(1,20);
include"$rand.jpg";



?>