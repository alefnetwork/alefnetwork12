<?php

if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
$protocol = $_SERVER['SERVER_PROTOCOL'];
if ( ! in_array( $protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0' ) ) ) {
$protocol = 'HTTP/1.0';
}

header( 'Allow: POST' );
header( "$protocol 405 Method Not Allowed" );
header( 'Content-Type: text/plain' );
exit;
}

function bank_information($cardn){
    $cardn = (integer)$cardn;
    if ($cardn == 603799 || $cardn == 170019 || $cardn == 589905) {
      $bankname = "#MELI";

      }elseif ($cardn == 589210) {
        $bankname = "#SEPAH";
        
      }elseif ($cardn == 627648 || $cardn == 207177) {
        $bankname = "#TOSEE_SADERAT";

      }elseif ($cardn == 627961) {
        $bankname = "#SANAT_MADAN";

      }elseif ($cardn == 603770 || $cardn == 639217) {
        $bankname = "#KESHAVARZI";
        
      }elseif ($cardn == 628023) {
        $bankname = "#MASKAN";

      }elseif ($cardn == 627760) {
        $bankname = "#POSTBANK";
    
      }elseif ($cardn == 502908) {
        $bankname = "#TOSEE_TAAVON";
        
      }elseif ($cardn == 627412) {
        $bankname = "#EGHTESAD_NOVIN";
        
      }elseif ($cardn == 622106 || $cardn == 639194 || $cardn == 627884) {
        $bankname = "#PARSIAN";
        
      }elseif ($cardn == 502229 || $cardn == 639347) {
        $bankname = "#PASARGAD";

      }elseif ($cardn == 627488 || $cardn == 502910) {
        $bankname = "#KARAFARIN";

      }elseif ($cardn == 621986) {
        $bankname = "#SAMAN";

      }elseif ($cardn == 639346) {
        $bankname = "#SINA";
        
      }elseif ($cardn == 639607) {
        $bankname = "#SARMAYE";

      }elseif ($cardn == 636214) {
        $bankname = "#AYANDE";

      }elseif ($cardn == 502806 || $cardn == 504706) {
        $bankname = "#SHAHR";

      }elseif ($cardn == 502938) {
        $bankname = "#DAY";

      }elseif ($cardn == 603769) {
        $bankname = "#SADERAT";

      }elseif ($cardn == 610433 || $cardn == 991975) {
        $bankname = "#MELLAT";

      }elseif ($cardn == 585983) {
        $bankname = "#TEJARAT";

      }elseif ($cardn == 589463) {
        $bankname = "#REFAH";

      }elseif ($cardn == 627381) {
        $bankname = "#ANSAR";

      }elseif ($cardn == 505785) {
        $bankname = "#IRAN_ZAMIN";

      }elseif ($cardn == 636795) {
        $bankname = "#MARKAZI";

      }elseif ($cardn == 636949) {
        $bankname = "#HEKMAT";

      }elseif ($cardn == 505416) {
        $bankname = "#GARDESHGARI";

      }elseif ($cardn == 606373) {
        $bankname = "#QARZOLHASANE";

      }elseif ($cardn == 628157) {
        $bankname = "#MOESSE_TOSEE";

      }elseif ($cardn == 505801) {
        $bankname = "#KOSAR";

      }elseif ($cardn == 639370) {
        $bankname = "#MOSSE_MEHR";

      }elseif ($cardn == 639599) { 
        $bankname = "#QAVAMIN";

      }else{
        $bankname = "#FAKE";
        $bankinfo = "CARDFAKE";
    
      }
      return array($bankinfo,$bankname);
}

?>
